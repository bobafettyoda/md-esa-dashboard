"""ETL sketch for Maryland ESA Dashboard.

This file intentionally avoids hard-coding changing service URLs. Use the source notes
in docs/data-sources.md, download authoritative datasets, then run this pattern.
"""

from pathlib import Path
import geopandas as gpd
from sqlalchemy import create_engine

DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/md_esa"
DATA = Path("data")


def load_layer(path: Path, table: str, where_md: bool = True) -> None:
    gdf = gpd.read_file(path).to_crs(4326)
    if where_md and "STATEFP" in gdf.columns:
        gdf = gdf[gdf["STATEFP"] == "24"]
    engine = create_engine(DATABASE_URL)
    gdf.to_postgis(table, engine, if_exists="append", index=False)


if __name__ == "__main__":
    print("Download source data into ./data, normalize columns, then call load_layer().")
