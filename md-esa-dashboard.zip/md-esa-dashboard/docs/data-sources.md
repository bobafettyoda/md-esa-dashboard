# Maryland data sources

## Federal

- USFWS ECOSphere/IPaC: ESA threatened and endangered species by location.
- USFWS Critical Habitat: active proposed and final critical habitat spatial data.
- NOAA Fisheries National ESA Critical Habitat Mapper: NOAA-designated ESA critical habitat.
- USGS PAD-US: protected areas inventory.
- Census TIGER/Line: county and congressional district boundaries.
- USGS Watershed Boundary Dataset: HUC watersheds.

## Maryland

- Maryland iMAP GIS Catalog: statewide GIS portal.
- Maryland DNR Sensitive Species Project Review Areas: buffered areas that primarily contain habitat for rare, threatened, endangered species and rare natural communities.
- Maryland DNR Wildlife and Rare Species Habitats: biodiversity conservation significance tiers.

## Notes

For legal or regulatory decisions, the dashboard should link back to the official federal or state source and warn that mapped data may not be a legal survey or complete regulatory determination.
