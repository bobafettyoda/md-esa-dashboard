CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS postgis_topology;

CREATE TABLE IF NOT EXISTS geounits (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  unit_type TEXT NOT NULL CHECK (unit_type IN ('county','huc','refuge','congressional_district')),
  source TEXT,
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS geounits_geom_idx ON geounits USING GIST (geom);

CREATE TABLE IF NOT EXISTS species (
  id TEXT PRIMARY KEY,
  scientific_name TEXT NOT NULL,
  common_name TEXT,
  esa_status TEXT,
  taxon TEXT,
  lead_agency TEXT CHECK (lead_agency IN ('USFWS','NOAA Fisheries','Joint','Unknown')) DEFAULT 'Unknown',
  source_url TEXT
);

CREATE TABLE IF NOT EXISTS species_range (
  id BIGSERIAL PRIMARY KEY,
  species_id TEXT REFERENCES species(id),
  source TEXT,
  occurrence_type TEXT DEFAULT 'range',
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS species_range_geom_idx ON species_range USING GIST (geom);

CREATE TABLE IF NOT EXISTS critical_habitat (
  id TEXT PRIMARY KEY,
  species_id TEXT REFERENCES species(id),
  habitat_name TEXT,
  status TEXT,
  source_agency TEXT CHECK (source_agency IN ('USFWS','NOAA Fisheries','Joint','Unknown')) DEFAULT 'Unknown',
  designation_date DATE,
  source_url TEXT,
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS critical_habitat_geom_idx ON critical_habitat USING GIST (geom);

CREATE TABLE IF NOT EXISTS protected_areas (
  id TEXT PRIMARY KEY,
  name TEXT,
  manager TEXT,
  owner_type TEXT,
  designation TEXT,
  gap_status TEXT,
  source TEXT DEFAULT 'PAD-US',
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX IF NOT EXISTS protected_areas_geom_idx ON protected_areas USING GIST (geom);

CREATE OR REPLACE VIEW species_by_geounit AS
SELECT DISTINCT
  g.id AS geounit_id,
  g.name AS geounit_name,
  g.unit_type,
  s.id AS species_id,
  s.common_name,
  s.scientific_name,
  s.esa_status,
  s.lead_agency,
  s.taxon
FROM geounits g
JOIN species_range r ON ST_Intersects(g.geom, r.geom)
JOIN species s ON s.id = r.species_id;
