const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

type Species = {
  species_id: string;
  common_name: string | null;
  scientific_name: string;
  esa_status: string | null;
  lead_agency: string;
  taxon: string | null;
};

async function getExampleSpecies(): Promise<Species[]> {
  // Replace with a selected Maryland geounit id after loading county boundaries.
  return [];
}

export default async function Home() {
  const species = await getExampleSpecies();
  return (
    <main style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>Maryland ESA Habitat Dashboard</h1>
      <p>
        MVP scaffold for Maryland ESA-listed species, critical habitat, protected-area overlap,
        and habitat gap analysis.
      </p>
      <section>
        <h2>First build target</h2>
        <ol>
          <li>Load Maryland counties into <code>geounits</code>.</li>
          <li>Load USFWS and NOAA critical habitat clipped to Maryland.</li>
          <li>Load PAD-US protected areas clipped to Maryland.</li>
          <li>Run county-level species and protected-overlap reports.</li>
        </ol>
      </section>
      <section>
        <h2>API endpoints</h2>
        <ul>
          <li><code>{API}/geounits</code></li>
          <li><code>{API}/geounits/:id/species</code></li>
          <li><code>{API}/geounits/:id/critical-habitat</code></li>
          <li><code>{API}/geounits/:id/habitat-overlap</code></li>
        </ul>
      </section>
    </main>
  );
}
