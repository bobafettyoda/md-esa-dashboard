# Maryland ESA Habitat Dashboard

Open-source starter dashboard for Maryland endangered species, designated critical habitat, protected land overlap, and habitat gap analysis.

## MVP questions

1. Which ESA-listed species occur in a Maryland county, watershed, refuge, or congressional district?
2. Where is designated critical habitat?
3. How much critical habitat overlaps protected land?
4. Which habitats are unprotected or fragmented?
5. Which agency has jurisdiction: USFWS, NOAA Fisheries, or joint?

## Stack

- API: FastAPI
- Database: PostgreSQL + PostGIS
- Frontend: Next.js + MapLibre GL JS
- ETL: Python + GeoPandas

## Priority data sources

- USFWS ECOSphere / IPaC for ESA species by location
- USFWS Critical Habitat spatial data
- NOAA Fisheries National ESA Critical Habitat Mapper for marine/NOAA species
- USGS PAD-US for protected areas
- Maryland iMAP / Maryland DNR SSPRA for state rare/sensitive species review areas
- US Census TIGER/Line for counties and congressional districts
- USGS WBD for HUC watersheds

## Local dev

```bash
cp .env.example .env
docker compose up --build
```

API: http://localhost:8000
Web: http://localhost:3000
