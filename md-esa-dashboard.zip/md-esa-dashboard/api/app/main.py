import os
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from psycopg_pool import ConnectionPool

DATABASE_URL = os.environ.get("DATABASE_URL")
pool = ConnectionPool(DATABASE_URL, open=False) if DATABASE_URL else None

app = FastAPI(title="Maryland ESA Habitat Dashboard API")

@app.on_event("startup")
def startup() -> None:
    if pool:
        pool.open()

@app.on_event("shutdown")
def shutdown() -> None:
    if pool:
        pool.close()

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}

@app.get("/geounits")
def geounits(unit_type: str | None = Query(default=None)) -> list[dict[str, Any]]:
    sql = "SELECT id, name, unit_type, source FROM geounits"
    params: list[Any] = []
    if unit_type:
        sql += " WHERE unit_type = %s"
        params.append(unit_type)
    sql += " ORDER BY unit_type, name"
    return query(sql, params)

@app.get("/geounits/{geounit_id}/species")
def geounit_species(geounit_id: str) -> list[dict[str, Any]]:
    return query(
        """
        SELECT species_id, common_name, scientific_name, esa_status, lead_agency, taxon
        FROM species_by_geounit
        WHERE geounit_id = %s
        ORDER BY common_name NULLS LAST, scientific_name
        """,
        [geounit_id],
    )

@app.get("/geounits/{geounit_id}/critical-habitat")
def geounit_critical_habitat(geounit_id: str) -> list[dict[str, Any]]:
    return query(
        """
        SELECT
          ch.id,
          s.common_name,
          s.scientific_name,
          ch.habitat_name,
          ch.status,
          ch.source_agency,
          ROUND((ST_Area(ST_Intersection(ch.geom, g.geom)::geography) / 4046.8564224)::numeric, 2) AS acres_in_geounit
        FROM geounits g
        JOIN critical_habitat ch ON ST_Intersects(g.geom, ch.geom)
        LEFT JOIN species s ON s.id = ch.species_id
        WHERE g.id = %s
        ORDER BY acres_in_geounit DESC
        """,
        [geounit_id],
    )

@app.get("/geounits/{geounit_id}/habitat-overlap")
def habitat_overlap(geounit_id: str) -> list[dict[str, Any]]:
    return query(
        """
        WITH habitat AS (
          SELECT ch.id, ch.species_id, ST_Intersection(ch.geom, g.geom) AS geom
          FROM critical_habitat ch
          JOIN geounits g ON ST_Intersects(ch.geom, g.geom)
          WHERE g.id = %s
        ), totals AS (
          SELECT id, species_id, ST_Area(geom::geography) AS total_m2
          FROM habitat
        ), protected AS (
          SELECT h.id, SUM(ST_Area(ST_Intersection(h.geom, pa.geom)::geography)) AS protected_m2
          FROM habitat h
          JOIN protected_areas pa ON ST_Intersects(h.geom, pa.geom)
          GROUP BY h.id
        )
        SELECT
          t.id AS critical_habitat_id,
          s.common_name,
          s.scientific_name,
          ROUND((t.total_m2 / 4046.8564224)::numeric, 2) AS total_acres,
          ROUND((COALESCE(p.protected_m2, 0) / 4046.8564224)::numeric, 2) AS protected_acres,
          ROUND((100 * COALESCE(p.protected_m2, 0) / NULLIF(t.total_m2, 0))::numeric, 2) AS protected_percent
        FROM totals t
        LEFT JOIN protected p ON p.id = t.id
        LEFT JOIN species s ON s.id = t.species_id
        ORDER BY protected_percent ASC NULLS LAST
        """,
        [geounit_id],
    )

def query(sql: str, params: list[Any]) -> list[dict[str, Any]]:
    if not pool:
        raise HTTPException(status_code=500, detail="DATABASE_URL is not configured")
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            columns = [desc.name for desc in cur.description]
            return [dict(zip(columns, row)) for row in cur.fetchall()]
