import os
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from psycopg_pool import ConnectionPool
from psycopg.rows import dict_row

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/md_esa")

pool = ConnectionPool(DATABASE_URL, kwargs={"row_factory": dict_row}, min_size=1, max_size=8, open=True)

app = FastAPI(title="Maryland ESA Habitat Dashboard API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@contextmanager
def db():
    with pool.connection() as conn:
        yield conn

@app.get("/")
def root():
    return {"name": "Maryland ESA Habitat Dashboard API", "status": "ok"}

@app.get("/health")
def health():
    with db() as conn:
        conn.execute("SELECT 1")
    return {"status": "ok"}

@app.get("/geounits")
def get_geounits():
    with db() as conn:
        rows = conn.execute(
            """
            SELECT id, name, unit_type, source
            FROM geounits
            ORDER BY name
            """
        ).fetchall()
    return rows

@app.get("/geounits/{geounit_id}/species")
def get_species_for_geounit(geounit_id: str):
    with db() as conn:
        geounit = conn.execute("SELECT id FROM geounits WHERE id = %s", (geounit_id,)).fetchone()
        if not geounit:
            raise HTTPException(status_code=404, detail="Geounit not found")
        rows = conn.execute(
            """
            SELECT DISTINCT s.id, s.scientific_name, s.common_name, s.esa_status, s.taxon, s.lead_agency, s.source_url
            FROM geounits g
            JOIN species_range r ON ST_Intersects(g.geom, r.geom)
            JOIN species s ON s.id = r.species_id
            WHERE g.id = %s
            ORDER BY s.common_name
            """,
            (geounit_id,),
        ).fetchall()
    return rows

@app.get("/geounits/{geounit_id}/critical-habitat")
def get_critical_habitat_for_geounit(geounit_id: str):
    with db() as conn:
        rows = conn.execute(
            """
            SELECT ch.id, ch.species_id, s.common_name, ch.habitat_type, ch.source,
                   ROUND((ST_Area(ST_Intersection(g.geom, ch.geom)::geography) / 4046.8564224)::numeric, 2) AS overlap_acres
            FROM geounits g
            JOIN critical_habitat ch ON ST_Intersects(g.geom, ch.geom)
            JOIN species s ON s.id = ch.species_id
            WHERE g.id = %s
            ORDER BY s.common_name
            """,
            (geounit_id,),
        ).fetchall()
    return rows

@app.get("/geounits/{geounit_id}/habitat-overlap")
def get_habitat_overlap(geounit_id: str):
    with db() as conn:
        rows = conn.execute(
            """
            WITH habitat AS (
              SELECT ch.id, ch.species_id, s.common_name, ST_Intersection(g.geom, ch.geom) AS geom
              FROM geounits g
              JOIN critical_habitat ch ON ST_Intersects(g.geom, ch.geom)
              JOIN species s ON s.id = ch.species_id
              WHERE g.id = %s
            ), protected AS (
              SELECT h.id AS habitat_id,
                     COALESCE(SUM(ST_Area(ST_Intersection(h.geom, pa.geom)::geography)) / 4046.8564224, 0) AS protected_acres
              FROM habitat h
              LEFT JOIN protected_areas pa ON ST_Intersects(h.geom, pa.geom)
              GROUP BY h.id
            )
            SELECT h.species_id, h.common_name,
                   ROUND((ST_Area(h.geom::geography) / 4046.8564224)::numeric, 2) AS habitat_acres,
                   ROUND(p.protected_acres::numeric, 2) AS protected_acres,
                   CASE WHEN ST_Area(h.geom::geography) = 0 THEN 0
                        ELSE ROUND(((p.protected_acres * 4046.8564224 / ST_Area(h.geom::geography)) * 100)::numeric, 1)
                   END AS protected_percent
            FROM habitat h
            JOIN protected p ON p.habitat_id = h.id
            ORDER BY h.common_name
            """,
            (geounit_id,),
        ).fetchall()
    return rows
