"use client";

import { useEffect, useMemo, useState } from "react";

type Geounit = { id: string; name: string; unit_type: string; source: string };
type Species = { id: string; scientific_name: string; common_name: string; esa_status: string; taxon: string; lead_agency: string; source_url?: string };
type Habitat = { id: number; species_id: string; common_name: string; habitat_type: string; source: string; overlap_acres: string };
type Overlap = { species_id: string; common_name: string; habitat_acres: string; protected_acres: string; protected_percent: string };

export default function Home() {
  const [geounits, setGeounits] = useState<Geounit[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [species, setSpecies] = useState<Species[]>([]);
  const [habitat, setHabitat] = useState<Habitat[]>([]);
  const [overlap, setOverlap] = useState<Overlap[]>([]);
  const [error, setError] = useState("");
  const selectedCounty = useMemo(() => geounits.find((g) => g.id === selectedId), [geounits, selectedId]);

  useEffect(() => {
    fetch("/api/geounits")
      .then((res) => res.json())
      .then((data) => {
        const counties = data.filter((g: Geounit) => g.unit_type === "county");
        setGeounits(counties);
        setSelectedId(counties[0]?.id || "");
      })
      .catch((e) => setError(`Could not load counties: ${e.message}`));
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    setError("");
    Promise.all([
      fetch(`/api/geounits/${selectedId}/species`).then((r) => r.json()),
      fetch(`/api/geounits/${selectedId}/critical-habitat`).then((r) => r.json()),
      fetch(`/api/geounits/${selectedId}/habitat-overlap`).then((r) => r.json()),
    ])
      .then(([speciesData, habitatData, overlapData]) => {
        setSpecies(speciesData);
        setHabitat(habitatData);
        setOverlap(overlapData);
      })
      .catch((e) => setError(`Could not load county analysis: ${e.message}`));
  }, [selectedId]);

  return (
    <main style={styles.page}>
      <section style={styles.hero}>
        <p style={styles.eyebrow}>Open-source conservation GIS MVP</p>
        <h1 style={styles.title}>Maryland ESA Habitat Dashboard</h1>
        <p style={styles.subtitle}>Select a Maryland county to see ESA-listed species, demo critical habitat, and protected-area overlap powered by FastAPI + PostGIS.</p>
      </section>

      <section style={styles.panel}>
        <label style={styles.label}>Maryland county</label>
        <select style={styles.select} value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
          {geounits.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>
        <p style={styles.note}>This v2 starts with demo geometries so the app works immediately. Replace them later with official Census/USFWS/NOAA layers.</p>
      </section>

      {error ? <section style={styles.error}>{error}</section> : null}

      <section style={styles.grid3}>
        <Metric label="Selected county" value={selectedCounty?.name || "Loading"} />
        <Metric label="ESA species found" value={species.length.toString()} />
        <Metric label="Critical habitat records" value={habitat.length.toString()} />
      </section>

      <section style={styles.columns}>
        <div style={styles.panel}>
          <h2 style={styles.heading}>Species present</h2>
          {species.length === 0 ? <p style={styles.muted}>No species ranges intersect this county.</p> : species.map((s) => (
            <article key={s.id} style={styles.card}>
              <div style={styles.cardHeader}>
                <strong>{s.common_name}</strong>
                <span style={styles.badge}>{s.esa_status}</span>
              </div>
              <p style={styles.italic}>{s.scientific_name}</p>
              <p style={styles.muted}>{s.taxon} · {s.lead_agency}</p>
            </article>
          ))}
        </div>

        <div style={styles.panel}>
          <h2 style={styles.heading}>Habitat protection</h2>
          {overlap.length === 0 ? <p style={styles.muted}>No critical habitat records intersect this county.</p> : overlap.map((o) => (
            <article key={o.species_id} style={styles.card}>
              <div style={styles.cardHeader}>
                <strong>{o.common_name}</strong>
                <span style={styles.badge}>{o.protected_percent}% protected</span>
              </div>
              <p style={styles.muted}>Habitat: {o.habitat_acres} acres</p>
              <p style={styles.muted}>Protected: {o.protected_acres} acres</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div style={styles.metric}><p style={styles.metricLabel}>{label}</p><p style={styles.metricValue}>{value}</p></div>;
}

const styles: Record<string, React.CSSProperties> = {
  page: { minHeight: "100vh", background: "#07111f", color: "white", fontFamily: "Arial, sans-serif", padding: 32 },
  hero: { maxWidth: 1000, margin: "0 auto 24px" },
  eyebrow: { color: "#7dd3fc", textTransform: "uppercase", letterSpacing: 1, fontSize: 12, fontWeight: 700 },
  title: { fontSize: 44, margin: "8px 0" },
  subtitle: { color: "#cbd5e1", fontSize: 18, maxWidth: 760, lineHeight: 1.5 },
  panel: { maxWidth: 1000, margin: "0 auto 24px", background: "#0f1b2e", border: "1px solid #23324a", borderRadius: 18, padding: 24 },
  label: { display: "block", color: "#cbd5e1", marginBottom: 8, fontWeight: 700 },
  select: { width: "100%", padding: 14, borderRadius: 10, background: "#17233a", color: "white", border: "1px solid #334155", fontSize: 16 },
  note: { color: "#94a3b8", fontSize: 14 },
  error: { maxWidth: 1000, margin: "0 auto 24px", background: "#7f1d1d", borderRadius: 12, padding: 16 },
  grid3: { maxWidth: 1000, margin: "0 auto 24px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 },
  metric: { background: "#0f1b2e", border: "1px solid #23324a", borderRadius: 18, padding: 20 },
  metricLabel: { color: "#94a3b8", margin: 0 },
  metricValue: { fontSize: 28, fontWeight: 800, margin: "8px 0 0" },
  columns: { maxWidth: 1000, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 24 },
  heading: { marginTop: 0 },
  card: { background: "#17233a", border: "1px solid #334155", borderRadius: 14, padding: 16, marginBottom: 14 },
  cardHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 },
  badge: { background: "#78350f", color: "#fde68a", borderRadius: 999, padding: "5px 10px", fontSize: 12, whiteSpace: "nowrap" },
  italic: { color: "#cbd5e1", fontStyle: "italic", margin: "8px 0" },
  muted: { color: "#94a3b8", margin: "6px 0" },
};
