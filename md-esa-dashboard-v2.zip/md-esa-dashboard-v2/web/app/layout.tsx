import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Maryland ESA Habitat Dashboard",
  description: "Maryland ESA-listed species and habitat dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}
