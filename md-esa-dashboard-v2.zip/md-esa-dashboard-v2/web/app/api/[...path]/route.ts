import { NextRequest, NextResponse } from "next/server";

const INTERNAL_API_URL = process.env.INTERNAL_API_URL || "http://api:8000";

type Params = { params: Promise<{ path: string[] }> };

async function proxy(req: NextRequest, context: Params) {
  const { path } = await context.params;
  const target = `${INTERNAL_API_URL}/${path.join("/")}${req.nextUrl.search}`;
  const res = await fetch(target, { method: req.method, headers: { accept: "application/json" } });
  const body = await res.text();
  return new NextResponse(body, {
    status: res.status,
    headers: { "content-type": res.headers.get("content-type") || "application/json" },
  });
}

export async function GET(req: NextRequest, context: Params) {
  return proxy(req, context);
}
