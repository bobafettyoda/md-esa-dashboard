# Maryland ESA Habitat Dashboard v2

A clean restart of the Maryland endangered species dashboard MVP.

This version is designed to work immediately in GitHub Codespaces with one Docker command.

## What is included

- Next.js frontend with county selector
- FastAPI backend
- PostgreSQL/PostGIS database
- Seeded demo Maryland counties
- Seeded demo ESA species
- Spatial-intersection species endpoint
- Critical habitat and protected-overlap demo endpoints

The built-in geometries are simplified demo boxes, not official boundaries. They are included so the app works instantly. Replace them later with official Census, USFWS, NOAA, PAD-US, and Maryland iMAP data.

## Run it

From the project folder:

```bash
docker compose up --build
```

Open the forwarded ports in Codespaces:

- Frontend: port 3000
- API: port 8000

## Test API

```bash
curl http://localhost:8000/geounits
curl http://localhost:8000/geounits/md-dorchester-county/species
curl http://localhost:8000/geounits/md-dorchester-county/critical-habitat
curl http://localhost:8000/geounits/md-dorchester-county/habitat-overlap
```

## Reset database

```bash
docker compose down -v
docker compose up --build
```

## Current demo behavior

- Dorchester County: Atlantic Sturgeon, Shortnose Sturgeon, Northern Long-eared Bat
- Worcester County: Piping Plover, Northern Long-eared Bat
- Anne Arundel County: Shortnose Sturgeon, Northern Long-eared Bat
- All demo counties: Northern Long-eared Bat

## Next real-data milestones

1. Replace demo county polygons with Census Maryland county geometries.
2. Replace demo species ranges with USFWS/NOAA occurrence, range, or critical habitat layers.
3. Load PAD-US protected areas clipped to Maryland.
4. Add a MapLibre map and county/habitat layers.
