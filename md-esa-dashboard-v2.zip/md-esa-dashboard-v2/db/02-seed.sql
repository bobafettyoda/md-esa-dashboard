-- Demo Maryland county polygons. These are simplified bounding boxes for MVP testing,
-- not official boundaries. Replace with Census TIGER/Line geometries later.
INSERT INTO geounits (id, name, unit_type, source, geom) VALUES
('md-dorchester-county', 'Dorchester County', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-76.4, 38.2, -75.7, 38.8, 4326))),
('md-worcester-county', 'Worcester County', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-75.7, 37.9, -75.0, 38.5, 4326))),
('md-anne-arundel-county', 'Anne Arundel County', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-77.0, 38.7, -76.3, 39.2, 4326))),
('md-garrett-county', 'Garrett County', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-79.5, 39.1, -78.8, 39.8, 4326))),
('md-baltimore-city', 'Baltimore city', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-76.8, 39.2, -76.45, 39.4, 4326))),
('md-montgomery-county', 'Montgomery County', 'county', 'demo built-in', ST_Multi(ST_MakeEnvelope(-77.6, 38.9, -76.9, 39.4, 4326)));

INSERT INTO species (id, scientific_name, common_name, esa_status, taxon, lead_agency, source_url) VALUES
('piping-plover', 'Charadrius melodus', 'Piping Plover', 'Threatened', 'Bird', 'USFWS', 'https://ecos.fws.gov/ecp/species/6039'),
('northern-long-eared-bat', 'Myotis septentrionalis', 'Northern Long-eared Bat', 'Endangered', 'Mammal', 'USFWS', 'https://ecos.fws.gov/ecp/species/9045'),
('atlantic-sturgeon', 'Acipenser oxyrinchus oxyrinchus', 'Atlantic Sturgeon', 'Endangered', 'Fish', 'NOAA Fisheries', 'https://www.fisheries.noaa.gov/species/atlantic-sturgeon'),
('shortnose-sturgeon', 'Acipenser brevirostrum', 'Shortnose Sturgeon', 'Endangered', 'Fish', 'NOAA Fisheries', 'https://www.fisheries.noaa.gov/species/shortnose-sturgeon');

-- Demo species ranges using selected county polygons to prove spatial intersections work.
INSERT INTO species_range (species_id, source, occurrence_type, geom)
SELECT 'piping-plover', 'demo county-based range', 'demo_range', geom FROM geounits WHERE id IN ('md-worcester-county');

INSERT INTO species_range (species_id, source, occurrence_type, geom)
SELECT 'atlantic-sturgeon', 'demo county-based range', 'demo_range', geom FROM geounits WHERE id IN ('md-dorchester-county');

INSERT INTO species_range (species_id, source, occurrence_type, geom)
SELECT 'shortnose-sturgeon', 'demo county-based range', 'demo_range', geom FROM geounits WHERE id IN ('md-dorchester-county', 'md-anne-arundel-county');

INSERT INTO species_range (species_id, source, occurrence_type, geom)
SELECT 'northern-long-eared-bat', 'demo statewide range', 'demo_range', geom FROM geounits;

INSERT INTO protected_areas (name, manager, source, geom) VALUES
('Blackwater National Wildlife Refuge demo area', 'USFWS', 'demo built-in', ST_Multi(ST_MakeEnvelope(-76.2, 38.25, -75.95, 38.45, 4326))),
('Assateague Island demo area', 'NPS/USFWS', 'demo built-in', ST_Multi(ST_MakeEnvelope(-75.35, 38.0, -75.1, 38.35, 4326)));

INSERT INTO critical_habitat (species_id, source, habitat_type, geom)
SELECT 'piping-plover', 'demo critical habitat', 'coastal beach', geom FROM geounits WHERE id='md-worcester-county';
INSERT INTO critical_habitat (species_id, source, habitat_type, geom)
SELECT 'atlantic-sturgeon', 'demo critical habitat', 'river/estuary', geom FROM geounits WHERE id='md-dorchester-county';
