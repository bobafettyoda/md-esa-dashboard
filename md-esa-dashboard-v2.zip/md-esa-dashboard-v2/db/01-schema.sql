CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE geounits (
  id text PRIMARY KEY,
  name text NOT NULL,
  unit_type text NOT NULL,
  source text,
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX geounits_geom_idx ON geounits USING GIST (geom);

CREATE TABLE species (
  id text PRIMARY KEY,
  scientific_name text NOT NULL,
  common_name text,
  esa_status text,
  taxon text,
  lead_agency text DEFAULT 'Unknown',
  source_url text
);

CREATE TABLE species_range (
  id bigserial PRIMARY KEY,
  species_id text REFERENCES species(id),
  source text,
  occurrence_type text DEFAULT 'demo_range',
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX species_range_geom_idx ON species_range USING GIST (geom);

CREATE TABLE critical_habitat (
  id bigserial PRIMARY KEY,
  species_id text REFERENCES species(id),
  source text,
  habitat_type text,
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX critical_habitat_geom_idx ON critical_habitat USING GIST (geom);

CREATE TABLE protected_areas (
  id bigserial PRIMARY KEY,
  name text NOT NULL,
  manager text,
  source text,
  geom geometry(MultiPolygon, 4326)
);
CREATE INDEX protected_areas_geom_idx ON protected_areas USING GIST (geom);
